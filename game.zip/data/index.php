<?
die('ERROR!');
?>